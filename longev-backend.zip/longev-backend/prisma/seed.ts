import { PrismaClient, Role, TenantType } from '@prisma/client';
import * as argon2 from 'argon2';

const prisma = new PrismaClient();

async function main() {
  const superAdminEmail = process.env.SEED_SUPER_ADMIN_EMAIL ?? 'admin@longev.com.br';
  const superAdminPassword = process.env.SEED_SUPER_ADMIN_PASSWORD ?? 'MudeEstaSenha123!';

  const existingAdmin = await prisma.user.findUnique({ where: { email: superAdminEmail } });
  if (!existingAdmin) {
    await prisma.user.create({
      data: {
        name: 'Super Admin Longev',
        email: superAdminEmail,
        passwordHash: await argon2.hash(superAdminPassword),
        role: Role.SUPER_ADMIN,
        tenantId: null,
      },
    });
    console.log(`Super admin criado: ${superAdminEmail}`);
  } else {
    console.log('Super admin já existe, pulando.');
  }

  // Tenant de demonstração para testes locais
  const demoDocument = '00000000000100';
  const existingDemoTenant = await prisma.tenant.findUnique({ where: { document: demoDocument } });

  if (!existingDemoTenant) {
    const demoTenant = await prisma.tenant.create({
      data: {
        name: 'Clínica Demo Longev',
        document: demoDocument,
        type: TenantType.CLINIC,
      },
    });

    await prisma.user.create({
      data: {
        tenantId: demoTenant.id,
        name: 'Dra. Demo',
        email: 'demo@longev.com.br',
        passwordHash: await argon2.hash('Demo12345!'),
        role: Role.OWNER,
      },
    });

    console.log('Tenant demo criado: demo@longev.com.br / Demo12345!');
  } else {
    console.log('Tenant demo já existe, pulando.');
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
