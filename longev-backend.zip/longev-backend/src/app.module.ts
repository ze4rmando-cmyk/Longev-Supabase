import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';

import { PrismaModule } from './modules/prisma/prisma.module';
import { CommonModule } from './common/common.module';
import { AuditModule } from './modules/audit/audit.module';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { TenantsModule } from './modules/tenants/tenants.module';
import { PatientsModule } from './modules/patients/patients.module';

import { JwtAuthGuard } from './common/guards/jwt-auth.guard';
import { AuditInterceptor } from './common/interceptors/audit.interceptor';
import { HealthController } from './health.controller';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ThrottlerModule.forRoot([
      {
        ttl: Number(process.env.THROTTLE_TTL ?? 60) * 1000,
        limit: Number(process.env.THROTTLE_LIMIT ?? 100),
      },
    ]),

    // Infraestrutura global
    PrismaModule,
    CommonModule,
    AuditModule,

    // Módulos de domínio
    AuthModule,
    UsersModule,
    TenantsModule,
    PatientsModule,
  ],
  controllers: [HealthController],
  providers: [
    // 1) Rate limiting em toda a API
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    // 2) Autenticação obrigatória por padrão (rotas @Public() ficam de fora)
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    // 3) Auditoria automática nas rotas marcadas com @Audit(...)
    { provide: APP_INTERCEPTOR, useClass: AuditInterceptor },
  ],
})
export class AppModule {}
