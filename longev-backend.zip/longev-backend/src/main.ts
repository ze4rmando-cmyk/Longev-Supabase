import { NestFactory } from '@nestjs/core';
import { ValidationPipe, VersioningType } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import helmet from 'helmet';
import { AppModule } from './app.module';
import { AllExceptionsFilter } from './common/filters/all-exceptions.filter';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    // Em produção, considere um logger estruturado (ex: pino) em vez do default
    logger: ['error', 'warn', 'log'],
  });

  // ---- Segurança de cabeçalhos HTTP ----
  app.use(helmet());

  // ---- CORS restrito à origem do frontend ----
  app.enableCors({
    origin: process.env.CORS_ORIGIN?.split(',') ?? 'http://localhost:5173',
    credentials: true,
  });

  // ---- Versionamento de API (/api/v1/...) ----
  app.setGlobalPrefix('api');
  app.enableVersioning({ type: VersioningType.URI, defaultVersion: '1' });

  // ---- Validação automática de DTOs em todas as rotas ----
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true, // remove campos não declarados no DTO
      forbidNonWhitelisted: true, // rejeita payload com campos extras
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
  );

  // ---- Filtro global de exceções (nunca expõe stack trace ao cliente) ----
  app.useGlobalFilters(new AllExceptionsFilter());

  // ---- Documentação Swagger (desabilitar em produção se desejar) ----
  if (process.env.NODE_ENV !== 'production') {
    const config = new DocumentBuilder()
      .setTitle('Longev API')
      .setDescription('API do sistema de gestão de clínicas geriátricas')
      .setVersion('1.0')
      .addBearerAuth()
      .build();
    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup('docs', app, document);
  }

  const port = process.env.PORT ?? 3000;
  await app.listen(port);
  // eslint-disable-next-line no-console
  console.log(`Longev API rodando na porta ${port}`);
}

bootstrap();
