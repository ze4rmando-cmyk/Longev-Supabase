import { Injectable, UnauthorizedException, ConflictException } from '@nestjs/common';
import * as argon2 from 'argon2';
import { PrismaService } from '@/modules/prisma/prisma.service';
import { TokenService } from './token.service';
import { AuditService } from '@/modules/audit/audit.service';
import { LoginDto } from './dto/login.dto';
import { RegisterTenantDto } from './dto/register-tenant.dto';
import { Role } from '@prisma/client';

interface RequestMeta {
  ipAddress?: string;
  userAgent?: string;
}

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tokenService: TokenService,
    private readonly auditService: AuditService,
  ) {}

  /**
   * Cadastro self-service: cria o Tenant (clínica ou profissional)
   * e o primeiro usuário (OWNER) em uma única transação.
   */
  async registerTenant(dto: RegisterTenantDto, meta?: RequestMeta) {
    const existingUser = await this.prisma.user.findUnique({
      where: { email: dto.ownerEmail },
    });
    if (existingUser) {
      throw new ConflictException('Este e-mail já está em uso.');
    }

    const existingTenant = await this.prisma.tenant.findUnique({
      where: { document: dto.document },
    });
    if (existingTenant) {
      throw new ConflictException('CPF/CNPJ já cadastrado.');
    }

    const passwordHash = await argon2.hash(dto.ownerPassword);

    const { tenant, user } = await this.prisma.$transaction(async (tx) => {
      const tenant = await tx.tenant.create({
        data: {
          name: dto.tenantName,
          document: dto.document,
          type: dto.tenantType,
        },
      });

      const user = await tx.user.create({
        data: {
          tenantId: tenant.id,
          name: dto.ownerName,
          email: dto.ownerEmail,
          passwordHash,
          role: Role.OWNER,
        },
      });

      return { tenant, user };
    });

    await this.auditService.record({
      tenantId: tenant.id,
      userId: user.id,
      action: 'TENANT_REGISTERED',
      entityType: 'Tenant',
      entityId: tenant.id,
      ipAddress: meta?.ipAddress,
      userAgent: meta?.userAgent,
    });

    return this.issueTokens(user, meta);
  }

  async login(dto: LoginDto, meta?: RequestMeta) {
    const user = await this.prisma.user.findUnique({ where: { email: dto.email } });

    // Resposta genérica propositalmente — não revelamos se o e-mail existe ou não
    const invalidCredentials = () => {
      void this.auditService.record({
        action: 'LOGIN_FAILED',
        metadata: { email: dto.email },
        ipAddress: meta?.ipAddress,
        userAgent: meta?.userAgent,
      });
      throw new UnauthorizedException('E-mail ou senha inválidos.');
    };

    if (!user || !user.isActive || user.deletedAt) {
      return invalidCredentials();
    }

    const passwordMatches = await argon2.verify(user.passwordHash, dto.password);
    if (!passwordMatches) {
      return invalidCredentials();
    }

    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    await this.auditService.record({
      tenantId: user.tenantId,
      userId: user.id,
      action: 'LOGIN_SUCCESS',
      ipAddress: meta?.ipAddress,
      userAgent: meta?.userAgent,
    });

    return this.issueTokens(user, meta);
  }

  async refresh(rawRefreshToken: string, meta?: RequestMeta) {
    const userId = await this.tokenService.validateAndRotateRefreshToken(rawRefreshToken);

    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user || !user.isActive || user.deletedAt) {
      throw new UnauthorizedException('Usuário inválido.');
    }

    return this.issueTokens(user, meta);
  }

  async logout(userId: string) {
    await this.tokenService.revokeAllUserTokens(userId);
    await this.auditService.record({ userId, action: 'LOGOUT' });
  }

  private async issueTokens(
    user: { id: string; tenantId: string | null; email: string; role: Role },
    meta?: RequestMeta,
  ) {
    const accessToken = this.tokenService.generateAccessToken(user);
    const refreshToken = await this.tokenService.generateRefreshToken(user.id, meta);

    return {
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        tenantId: user.tenantId,
        email: user.email,
        role: user.role,
      },
    };
  }
}
