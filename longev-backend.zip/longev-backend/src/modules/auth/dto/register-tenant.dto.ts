import { IsEmail, IsEnum, IsString, MinLength } from 'class-validator';
import { TenantType } from '@prisma/client';

export class RegisterTenantDto {
  // Dados do tenant (clínica ou profissional individual)
  @IsString()
  @MinLength(2)
  tenantName!: string;

  @IsString()
  @MinLength(11, { message: 'Informe um CPF ou CNPJ válido.' })
  document!: string;

  @IsEnum(TenantType)
  tenantType!: TenantType;

  // Dados do usuário responsável (será criado com role OWNER)
  @IsString()
  @MinLength(2)
  ownerName!: string;

  @IsEmail({}, { message: 'E-mail inválido.' })
  ownerEmail!: string;

  @IsString()
  @MinLength(8, { message: 'Senha deve ter ao menos 8 caracteres.' })
  ownerPassword!: string;
}
