import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';
import { PrismaService } from '@/modules/prisma/prisma.service';
import { User } from '@prisma/client';

interface RequestMeta {
  ipAddress?: string;
  userAgent?: string;
}

@Injectable()
export class TokenService {
  constructor(
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
    private readonly prisma: PrismaService,
  ) {}

  private hashToken(token: string): string {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  generateAccessToken(user: Pick<User, 'id' | 'tenantId' | 'email' | 'role'>): string {
    return this.jwtService.sign(
      { sub: user.id, tenantId: user.tenantId, email: user.email, role: user.role },
      {
        secret: this.configService.get<string>('JWT_ACCESS_SECRET'),
        expiresIn: this.configService.get<string>('JWT_ACCESS_EXPIRES_IN') ?? '15m',
      },
    );
  }

  /**
   * Cria um refresh token opaco (não-JWT), guarda apenas o HASH no
   * banco e retorna o valor em texto puro para o cliente uma única vez.
   * Isso evita que um vazamento do banco exponha tokens válidos.
   */
  async generateRefreshToken(userId: string, meta?: RequestMeta): Promise<string> {
    const rawToken = crypto.randomBytes(64).toString('hex');
    const expiresInDays = this.parseDays(
      this.configService.get<string>('JWT_REFRESH_EXPIRES_IN') ?? '7d',
    );

    await this.prisma.refreshToken.create({
      data: {
        userId,
        tokenHash: this.hashToken(rawToken),
        expiresAt: new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000),
        ipAddress: meta?.ipAddress,
        userAgent: meta?.userAgent,
      },
    });

    return rawToken;
  }

  /**
   * Valida o refresh token e o REVOGA imediatamente (rotação).
   * Um refresh token só pode ser usado uma vez — se reaparecer depois
   * de revogado, é forte indício de token roubado.
   */
  async validateAndRotateRefreshToken(rawToken: string): Promise<string> {
    const tokenHash = this.hashToken(rawToken);

    const stored = await this.prisma.refreshToken.findUnique({
      where: { tokenHash },
    });

    if (!stored || stored.revokedAt || stored.expiresAt < new Date()) {
      throw new UnauthorizedException('Refresh token inválido ou expirado.');
    }

    await this.prisma.refreshToken.update({
      where: { id: stored.id },
      data: { revokedAt: new Date() },
    });

    return stored.userId;
  }

  async revokeAllUserTokens(userId: string): Promise<void> {
    await this.prisma.refreshToken.updateMany({
      where: { userId, revokedAt: null },
      data: { revokedAt: new Date() },
    });
  }

  private parseDays(value: string): number {
    const match = /^(\d+)d$/.exec(value);
    return match ? parseInt(match[1], 10) : 7;
  }
}
