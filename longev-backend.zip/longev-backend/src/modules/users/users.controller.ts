import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { CurrentUser, AuthenticatedUser } from '@/common/decorators/current-user.decorator';
import { Roles } from '@/common/decorators/roles.decorator';
import { RolesGuard } from '@/common/guards/roles.guard';
import { TenantGuard } from '@/common/guards/tenant.guard';
import { Audit } from '@/common/decorators/audit.decorator';

@ApiTags('users')
@UseGuards(TenantGuard, RolesGuard)
@Controller({ path: 'users', version: '1' })
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  // Apenas o proprietário gerencia a equipe (criar/editar/remover acessos)
  @Roles(Role.OWNER)
  @Audit({ action: 'USER_CREATE', entityType: 'User' })
  @Post()
  create(@CurrentUser() currentUser: AuthenticatedUser, @Body() dto: CreateUserDto) {
    return this.usersService.create(currentUser.tenantId!, dto);
  }

  @Get()
  findAll(@CurrentUser() currentUser: AuthenticatedUser) {
    return this.usersService.findAll(currentUser.tenantId!);
  }

  @Get(':id')
  findOne(@CurrentUser() currentUser: AuthenticatedUser, @Param('id') id: string) {
    return this.usersService.findOne(currentUser.tenantId!, id);
  }

  @Roles(Role.OWNER)
  @Audit({ action: 'USER_UPDATE', entityType: 'User' })
  @Patch(':id')
  update(
    @CurrentUser() currentUser: AuthenticatedUser,
    @Param('id') id: string,
    @Body() dto: UpdateUserDto,
  ) {
    return this.usersService.update(currentUser.tenantId!, id, dto);
  }

  @Roles(Role.OWNER)
  @Audit({ action: 'USER_DEACTIVATE', entityType: 'User' })
  @Delete(':id')
  remove(@CurrentUser() currentUser: AuthenticatedUser, @Param('id') id: string) {
    return this.usersService.remove(currentUser.tenantId!, id);
  }
}
