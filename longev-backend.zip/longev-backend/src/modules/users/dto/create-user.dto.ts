import { IsEmail, IsEnum, IsOptional, IsString, MinLength } from 'class-validator';
import { Role } from '@prisma/client';

export class CreateUserDto {
  @IsString()
  @MinLength(2)
  name!: string;

  @IsEmail()
  email!: string;

  @IsString()
  @MinLength(8, { message: 'Senha provisória deve ter ao menos 8 caracteres.' })
  password!: string;

  @IsEnum(Role, { message: 'Perfil inválido.' })
  role!: Role;

  @IsOptional()
  @IsString()
  professionalRegister?: string;
}
