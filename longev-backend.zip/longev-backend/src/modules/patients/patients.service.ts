import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '@/modules/prisma/prisma.service';
import { EncryptionService } from '@/common/utils/encryption.service';
import { CreatePatientDto } from './dto/create-patient.dto';
import { UpdatePatientDto } from './dto/update-patient.dto';
import { Patient } from '@prisma/client';

type DecryptedPatient = Omit<
  Patient,
  'healthConditionsEnc' | 'allergiesEnc' | 'medicationsEnc' | 'notesEnc'
> & {
  healthConditions: string | null;
  allergies: string | null;
  medications: string | null;
  notes: string | null;
};

@Injectable()
export class PatientsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly encryption: EncryptionService,
  ) {}

  private decryptPatient(patient: Patient): DecryptedPatient {
    const { healthConditionsEnc, allergiesEnc, medicationsEnc, notesEnc, ...rest } = patient;
    return {
      ...rest,
      healthConditions: this.encryption.decrypt(healthConditionsEnc),
      allergies: this.encryption.decrypt(allergiesEnc),
      medications: this.encryption.decrypt(medicationsEnc),
      notes: this.encryption.decrypt(notesEnc),
    };
  }

  async create(tenantId: string, dto: CreatePatientDto) {
    const patient = await this.prisma.patient.create({
      data: {
        tenantId,
        fullName: dto.fullName,
        birthDate: new Date(dto.birthDate),
        sex: dto.sex,
        healthConditionsEnc: this.encryption.encrypt(dto.healthConditions),
        allergiesEnc: this.encryption.encrypt(dto.allergies),
        medicationsEnc: this.encryption.encrypt(dto.medications),
        notesEnc: this.encryption.encrypt(dto.notes),
      },
    });
    return this.decryptPatient(patient);
  }

  // SEMPRE filtra por tenantId — este é o ponto central do isolamento
  // multi-tenant: uma clínica nunca recebe pacientes de outra clínica,
  // independente do que vier na URL ou no body da requisição.
  async findAll(tenantId: string) {
    const patients = await this.prisma.patient.findMany({
      where: { tenantId, deletedAt: null },
      orderBy: { createdAt: 'desc' },
    });
    return patients.map((p) => this.decryptPatient(p));
  }

  async findOne(tenantId: string, id: string) {
    const patient = await this.prisma.patient.findFirst({
      where: { id, tenantId, deletedAt: null },
    });
    if (!patient) throw new NotFoundException('Paciente não encontrado.');
    return this.decryptPatient(patient);
  }

  async update(tenantId: string, id: string, dto: UpdatePatientDto) {
    await this.assertBelongsToTenant(tenantId, id);

    const patient = await this.prisma.patient.update({
      where: { id },
      data: {
        fullName: dto.fullName,
        birthDate: dto.birthDate ? new Date(dto.birthDate) : undefined,
        sex: dto.sex,
        status: dto.status,
        ...(dto.healthConditions !== undefined && {
          healthConditionsEnc: this.encryption.encrypt(dto.healthConditions),
        }),
        ...(dto.allergies !== undefined && {
          allergiesEnc: this.encryption.encrypt(dto.allergies),
        }),
        ...(dto.medications !== undefined && {
          medicationsEnc: this.encryption.encrypt(dto.medications),
        }),
        ...(dto.notes !== undefined && { notesEnc: this.encryption.encrypt(dto.notes) }),
      },
    });
    return this.decryptPatient(patient);
  }

  async remove(tenantId: string, id: string) {
    await this.assertBelongsToTenant(tenantId, id);
    await this.prisma.patient.update({ where: { id }, data: { deletedAt: new Date() } });
    return { success: true };
  }

  private async assertBelongsToTenant(tenantId: string, id: string) {
    const exists = await this.prisma.patient.findFirst({
      where: { id, tenantId, deletedAt: null },
      select: { id: true },
    });
    if (!exists) throw new NotFoundException('Paciente não encontrado.');
  }
}
