import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { PatientsService } from './patients.service';
import { CreatePatientDto } from './dto/create-patient.dto';
import { UpdatePatientDto } from './dto/update-patient.dto';
import { CurrentUser, AuthenticatedUser } from '@/common/decorators/current-user.decorator';
import { Roles } from '@/common/decorators/roles.decorator';
import { RolesGuard } from '@/common/guards/roles.guard';
import { TenantGuard } from '@/common/guards/tenant.guard';
import { Audit } from '@/common/decorators/audit.decorator';

@ApiTags('patients')
@UseGuards(TenantGuard, RolesGuard)
@Controller({ path: 'patients', version: '1' })
export class PatientsController {
  constructor(private readonly patientsService: PatientsService) {}

  // Recepção pode cadastrar; financeiro não precisa criar pacientes
  @Roles(Role.OWNER, Role.DOCTOR, Role.NURSE, Role.RECEPTIONIST)
  @Audit({ action: 'PATIENT_CREATE', entityType: 'Patient' })
  @Post()
  create(@CurrentUser() user: AuthenticatedUser, @Body() dto: CreatePatientDto) {
    return this.patientsService.create(user.tenantId!, dto);
  }

  @Audit({ action: 'PATIENT_LIST', entityType: 'Patient' })
  @Get()
  findAll(@CurrentUser() user: AuthenticatedUser) {
    return this.patientsService.findAll(user.tenantId!);
  }

  // Acesso a um prontuário individual é o ponto mais sensível do sistema —
  // por isso é sempre auditado, mesmo que seja só leitura.
  @Audit({ action: 'PATIENT_VIEW', entityType: 'Patient' })
  @Get(':id')
  findOne(@CurrentUser() user: AuthenticatedUser, @Param('id') id: string) {
    return this.patientsService.findOne(user.tenantId!, id);
  }

  @Roles(Role.OWNER, Role.DOCTOR, Role.NURSE)
  @Audit({ action: 'PATIENT_UPDATE', entityType: 'Patient' })
  @Patch(':id')
  update(
    @CurrentUser() user: AuthenticatedUser,
    @Param('id') id: string,
    @Body() dto: UpdatePatientDto,
  ) {
    return this.patientsService.update(user.tenantId!, id, dto);
  }

  @Roles(Role.OWNER, Role.DOCTOR)
  @Audit({ action: 'PATIENT_DELETE', entityType: 'Patient' })
  @Delete(':id')
  remove(@CurrentUser() user: AuthenticatedUser, @Param('id') id: string) {
    return this.patientsService.remove(user.tenantId!, id);
  }
}
