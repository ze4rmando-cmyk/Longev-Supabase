import { PartialType } from '@nestjs/swagger';
import { CreatePatientDto } from './create-patient.dto';
import { IsEnum, IsOptional } from 'class-validator';
import { PatientStatus } from '@prisma/client';

export class UpdatePatientDto extends PartialType(CreatePatientDto) {
  @IsOptional()
  @IsEnum(PatientStatus)
  status?: PatientStatus;
}
