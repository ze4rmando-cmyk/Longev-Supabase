import { IsDateString, IsEnum, IsOptional, IsString, MinLength } from 'class-validator';
import { Sex } from '@prisma/client';

export class CreatePatientDto {
  @IsString()
  @MinLength(2)
  fullName!: string;

  @IsDateString()
  birthDate!: string;

  @IsEnum(Sex)
  sex!: Sex;

  @IsOptional()
  @IsString()
  healthConditions?: string;

  @IsOptional()
  @IsString()
  allergies?: string;

  @IsOptional()
  @IsString()
  medications?: string;

  @IsOptional()
  @IsString()
  notes?: string;
}
