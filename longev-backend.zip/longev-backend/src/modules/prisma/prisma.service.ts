import { Injectable, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

/**
 * Wrapper do PrismaClient.
 *
 * Decisão importante: o isolamento de tenant é garantido EXPLICITAMENTE
 * em cada query dos services (sempre filtrando por tenantId), e reforçado
 * pelo TenantGuard na camada HTTP. Não confiamos em "esquecer o where"
 * em nenhum lugar — todo service de dominio recebe o tenantId do
 * contexto autenticado e o usa obrigatoriamente.
 *
 * Para Postgres com Row Level Security (RLS) habilitado futuramente,
 * basta configurar a connection a usar `SET app.current_tenant_id`
 * por request — deixamos a estrutura pronta para essa evolução.
 */
@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  async onModuleInit() {
    await this.$connect();
  }

  async onModuleDestroy() {
    await this.$disconnect();
  }
}
