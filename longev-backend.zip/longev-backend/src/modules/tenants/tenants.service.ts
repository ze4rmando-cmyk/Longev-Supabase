import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '@/modules/prisma/prisma.service';
import { TenantPlan, TenantStatus } from '@prisma/client';

@Injectable()
export class TenantsService {
  constructor(private readonly prisma: PrismaService) {}

  // Uso exclusivo do SUPER_ADMIN — visão de todas as clínicas da plataforma
  async findAll() {
    return this.prisma.tenant.findMany({
      where: { deletedAt: null },
      orderBy: { createdAt: 'desc' },
      include: { _count: { select: { users: true, patients: true } } },
    });
  }

  async findOne(id: string) {
    const tenant = await this.prisma.tenant.findFirst({ where: { id, deletedAt: null } });
    if (!tenant) throw new NotFoundException('Clínica não encontrada.');
    return tenant;
  }

  async updateStatus(id: string, status: TenantStatus) {
    await this.findOne(id);
    return this.prisma.tenant.update({ where: { id }, data: { status } });
  }

  async updatePlan(id: string, plan: TenantPlan) {
    await this.findOne(id);
    return this.prisma.tenant.update({ where: { id }, data: { plan } });
  }

  // Usado pelo próprio tenant para ver seus dados (sem expor outras clínicas)
  async findOwn(tenantId: string) {
    return this.findOne(tenantId);
  }
}
