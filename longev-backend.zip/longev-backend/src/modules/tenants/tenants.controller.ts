import { Body, Controller, Get, Param, Patch, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Role, TenantPlan, TenantStatus } from '@prisma/client';
import { TenantsService } from './tenants.service';
import { Roles } from '@/common/decorators/roles.decorator';
import { RolesGuard } from '@/common/guards/roles.guard';
import { CurrentUser, AuthenticatedUser } from '@/common/decorators/current-user.decorator';
import { Audit } from '@/common/decorators/audit.decorator';

@ApiTags('tenants')
@Controller({ path: 'tenants', version: '1' })
export class TenantsController {
  constructor(private readonly tenantsService: TenantsService) {}

  // Painel administrativo Longev — apenas equipe interna
  @UseGuards(RolesGuard)
  @Roles(Role.SUPER_ADMIN)
  @Get()
  findAll() {
    return this.tenantsService.findAll();
  }

  @UseGuards(RolesGuard)
  @Roles(Role.SUPER_ADMIN)
  @Audit({ action: 'TENANT_STATUS_UPDATE', entityType: 'Tenant' })
  @Patch(':id/status')
  updateStatus(@Param('id') id: string, @Body('status') status: TenantStatus) {
    return this.tenantsService.updateStatus(id, status);
  }

  @UseGuards(RolesGuard)
  @Roles(Role.SUPER_ADMIN)
  @Audit({ action: 'TENANT_PLAN_UPDATE', entityType: 'Tenant' })
  @Patch(':id/plan')
  updatePlan(@Param('id') id: string, @Body('plan') plan: TenantPlan) {
    return this.tenantsService.updatePlan(id, plan);
  }

  // Qualquer usuário autenticado pode ver os dados da PRÓPRIA clínica
  @Get('me')
  findOwn(@CurrentUser() user: AuthenticatedUser) {
    return this.tenantsService.findOwn(user.tenantId!);
  }
}
