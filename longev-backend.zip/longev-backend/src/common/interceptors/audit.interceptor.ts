import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { AuditService } from '@/modules/audit/audit.service';
import { AUDIT_ACTION_KEY, AuditMeta } from '@/common/decorators/audit.decorator';

/**
 * Aplicado globalmente. Sempre que um endpoint estiver marcado com
 * @Audit(...), grava quem acessou o quê, de onde e quando — após a
 * resposta ser enviada, sem atrasar o usuário.
 *
 * Importante: isto cobre ações marcadas explicitamente (rotas de
 * negócio sensíveis). Login/logout são auditados diretamente no
 * AuthService, pois acontecem antes de existir um JWT válido.
 */
@Injectable()
export class AuditInterceptor implements NestInterceptor {
  constructor(
    private readonly reflector: Reflector,
    private readonly auditService: AuditService,
  ) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const auditMeta = this.reflector.getAllAndOverride<AuditMeta | undefined>(
      AUDIT_ACTION_KEY,
      [context.getHandler(), context.getClass()],
    );

    if (!auditMeta) {
      return next.handle();
    }

    const request = context.switchToHttp().getRequest();
    const { user, method, originalUrl, params } = request;

    return next.handle().pipe(
      tap((result) => {
        const entityId = params?.id ?? result?.id;
        void this.auditService.record({
          tenantId: user?.tenantId,
          userId: user?.id,
          action: auditMeta.action,
          entityType: auditMeta.entityType,
          entityId,
          method,
          path: originalUrl,
          ipAddress: request.ip,
          userAgent: request.headers?.['user-agent'],
        });
      }),
    );
  }
}
