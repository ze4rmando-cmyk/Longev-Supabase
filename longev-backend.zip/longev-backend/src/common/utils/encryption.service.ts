import { Injectable, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12; // recomendado para GCM
const AUTH_TAG_LENGTH = 16;

/**
 * Criptografia em nível de campo para dados clínicos sensíveis
 * (condições de saúde, alergias, medicações, observações etc.)
 * antes de gravar no banco.
 *
 * Formato armazenado: base64(iv) + ':' + base64(authTag) + ':' + base64(cipherText)
 *
 * Observação sobre LGPD/segurança: a chave (FIELD_ENCRYPTION_KEY)
 * NUNCA deve ficar no banco ou no código — apenas em variável de
 * ambiente / secret manager. Em produção, considere migrar para
 * um KMS gerenciado (AWS KMS, GCP KMS) para rotação de chaves.
 */
@Injectable()
export class EncryptionService implements OnModuleInit {
  private key!: Buffer;

  constructor(private readonly configService: ConfigService) {}

  onModuleInit() {
    const hexKey = this.configService.get<string>('FIELD_ENCRYPTION_KEY');
    if (!hexKey || hexKey.length !== 64) {
      throw new Error(
        'FIELD_ENCRYPTION_KEY inválida: defina uma chave hex de 32 bytes (64 caracteres). ' +
          'Gere com: openssl rand -hex 32',
      );
    }
    this.key = Buffer.from(hexKey, 'hex');
  }

  encrypt(plainText: string | null | undefined): string | null {
    if (plainText === null || plainText === undefined || plainText === '') return null;

    const iv = crypto.randomBytes(IV_LENGTH);
    const cipher = crypto.createCipheriv(ALGORITHM, this.key, iv, {
      authTagLength: AUTH_TAG_LENGTH,
    });

    const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
    const authTag = cipher.getAuthTag();

    return [iv.toString('base64'), authTag.toString('base64'), encrypted.toString('base64')].join(
      ':',
    );
  }

  decrypt(payload: string | null | undefined): string | null {
    if (!payload) return null;

    const [ivB64, authTagB64, cipherTextB64] = payload.split(':');
    if (!ivB64 || !authTagB64 || !cipherTextB64) {
      throw new Error('Formato de dado criptografado inválido.');
    }

    const iv = Buffer.from(ivB64, 'base64');
    const authTag = Buffer.from(authTagB64, 'base64');
    const cipherText = Buffer.from(cipherTextB64, 'base64');

    const decipher = crypto.createDecipheriv(ALGORITHM, this.key, iv, {
      authTagLength: AUTH_TAG_LENGTH,
    });
    decipher.setAuthTag(authTag);

    const decrypted = Buffer.concat([decipher.update(cipherText), decipher.final()]);
    return decrypted.toString('utf8');
  }
}
