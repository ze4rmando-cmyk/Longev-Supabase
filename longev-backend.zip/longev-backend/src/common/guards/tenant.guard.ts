import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Role } from '@prisma/client';

/**
 * Camada extra de proteção multi-tenant.
 *
 * Regra: todo usuário que NÃO seja SUPER_ADMIN precisa ter um
 * tenantId válido para acessar rotas de negócio. Isso evita que
 * um usuário "órfão" (sem tenant) consiga, por qualquer falha de
 * lógica em outro lugar, acessar dados de qualquer clínica.
 *
 * O isolamento "clínica A não vê clínica B" é reforçado nos
 * services (toda query inclui where: { tenantId }), e este guard
 * garante que sempre existe um tenantId confiável vindo do JWT
 * antes de a requisição chegar lá.
 */
@Injectable()
export class TenantGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const { user } = context.switchToHttp().getRequest();

    if (!user) {
      throw new ForbiddenException('Usuário não autenticado.');
    }

    if (user.role === Role.SUPER_ADMIN) {
      return true; // opera fora do contexto de tenant (painel administrativo)
    }

    if (!user.tenantId) {
      throw new ForbiddenException(
        'Usuário sem clínica/tenant associado. Contate o administrador.',
      );
    }

    return true;
  }
}
