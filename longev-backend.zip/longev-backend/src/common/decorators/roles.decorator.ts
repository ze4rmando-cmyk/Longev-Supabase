import { SetMetadata } from '@nestjs/common';
import { Role } from '@prisma/client';

export const ROLES_KEY = 'roles';

/**
 * Restringe o acesso de uma rota a perfis específicos.
 * Uso: @Roles(Role.OWNER, Role.DOCTOR)
 */
export const Roles = (...roles: Role[]) => SetMetadata(ROLES_KEY, roles);
