import { SetMetadata } from '@nestjs/common';

export const IS_PUBLIC_KEY = 'isPublic';

/**
 * Marca uma rota como pública (ex: login, refresh).
 * Todas as outras rotas exigem autenticação por padrão —
 * isso é proposital: em um sistema de saúde, "seguro por padrão"
 * é melhor do que "aberto por padrão".
 */
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);
