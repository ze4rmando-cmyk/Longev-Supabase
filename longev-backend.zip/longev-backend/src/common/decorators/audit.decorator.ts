import { SetMetadata } from '@nestjs/common';

export const AUDIT_ACTION_KEY = 'auditAction';

export interface AuditMeta {
  action: string; // ex: "PATIENT_VIEW", "PATIENT_CREATE", "PATIENT_UPDATE"
  entityType?: string; // ex: "Patient"
}

/**
 * Marca uma rota para registro automático em audit log.
 * Uso: @Audit({ action: 'PATIENT_VIEW', entityType: 'Patient' })
 */
export const Audit = (meta: AuditMeta) => SetMetadata(AUDIT_ACTION_KEY, meta);
